# DSP MultiDistributor
A distributor can now transport with multiple distributors.<br>
This don't affect achievements or milestones. <br>
<br>
物流配送器が複数の物流配送器と輸送できるようになります。<br>
実績やマイルストーンには影響しません。<br>

## Features　特徴
If the items handled by the distributor are not set, the distributor will transport with multiple distributors.Both request and supply are possible.<br>
Targets items with filters set in the grid in the storage attached by the distributor. Currently only the top storage is targeted.<br>
When you close the distributor window, connection information with other distributors is updated and distribution begins.<br>
Simply setting the storage filter does not update the connection information.<br>
<br>
I have just created it, so I will make many improvements in the future.Please let me know if you have any ideas.<br>
<br>
物流配送器で取り扱うアイテムを設定していない場合、物流配送器は複数の物流配送器と搬送します。要求、供給ともに可能です。<br>
物流配送器が接続したストレージ内のグリッドにフィルターを設定したアイテムを対象とします。現在一番上のストレージのみが対象となります。<br>
物流配送器ウインドウを閉じたときに、他の物流配送器と接続情報が更新され、搬送が開始されます。<br>
ストレージのフィルターを設定しただけでは、接続情報が更新されません。<br>
<br>
まだ作ったばかりなので、今後いろいろ改良します。アイデアがありましたらお知らせください。<br>


## How to install　インストール方法
1. Install BepInEx<br>
2. Drag DSPMultiDistributor.dll into steamapps/common/Dyson Sphere Program/BepInEx/plugins<br>
<br>
1. BepInExをインストールします。<br>
2. DSPMultiDistributor.dllをsteamapps/common/Dyson Sphere Program/BepInEx/pluginsに配置します。<br>
<br>
## Contact 問い合わせ先
If you have any problems or suggestions, please contact DISCORD MSP Modding server **Appun#8284**.<br>
不具合、改善案などありましたら、DISCORD「DysonSphereProgram_Jp」サーバー**Appun#8284**までお願いします。<br>
<br>
## Change Log　更新履歴
### v0.0.2
- Fixed some bugs. いくつかのバグを解消しました。
### v0.0.1
- released, Supported the game version 0.10.28.21308. リリースしました。ゲームバージョン0.10.29.21950に対応しています。
